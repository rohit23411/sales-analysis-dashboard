# Sales Analysis Dashboard

Interactive dashboard: revenue, profit, units, region and category breakdown, top products.

## Structure
- `index.html` – the dashboard (open in any browser; needs internet for Chart.js)
- `data/sales_sample.csv` – sample dataset (year, month, region, category, product, units, revenue, profit)

## Next steps
- Replace the sample data with your own CSV using the same columns.
- Add new filters or charts in `index.html`.
